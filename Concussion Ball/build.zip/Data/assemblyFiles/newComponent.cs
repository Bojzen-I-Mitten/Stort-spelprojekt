﻿using ThomasEngine;

public class $itemname$ : ScriptComponent
{
    public override void Start()
    {
        
    }

    public override void Update()
    {
        
    }
}
